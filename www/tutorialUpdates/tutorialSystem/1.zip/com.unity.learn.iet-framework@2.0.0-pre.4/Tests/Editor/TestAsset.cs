using UnityEngine;

namespace Unity.Tutorials.Core.Editor.Tests
{
    class TestAsset : ScriptableObject {}
}
