using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.InternalAPIEditorBridgeDev.002")]
