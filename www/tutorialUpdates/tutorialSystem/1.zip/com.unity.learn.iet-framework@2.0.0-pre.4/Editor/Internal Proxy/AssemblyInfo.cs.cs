using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.InternalAPIEditorBridgeDev.002")]
[assembly: InternalsVisibleTo("Unity.Tutorials.Core.Editor")]
[assembly: InternalsVisibleTo("Unity.Tutorials.Authoring.Editor")]
