using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.Tutorials.Authoring.Editor")]
[assembly: InternalsVisibleTo("Unity.InternalAPIEditorBridgeDev.002")]
